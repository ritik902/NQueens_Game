#!/bin/bash

set -e
APP_NAME="nqueens"
INSTALL_DIR="/opt/$APP_NAME"
WRAPPER="/usr/local/bin/$APP_NAME"
ICON_NAME="icon.png"
ICON_TARGET="/usr/share/pixmaps/${APP_NAME}.png"
DESKTOP_FILE="/usr/share/applications/${APP_NAME}.desktop"

# Create install dir and copy entire app
echo "📦 Installing N-Queens Game to $INSTALL_DIR..."
sudo mkdir -p "$INSTALL_DIR"
sudo cp -r ./NQueensGame-Linux/n_Queen.dist/* "$INSTALL_DIR/"
sudo chmod -R +x "$INSTALL_DIR"

# Install icon
sudo cp "$ICON_NAME" "$ICON_TARGET"

# Create wrapper
echo "🔧 Creating launcher script..."
sudo tee "$WRAPPER" > /dev/null <<EOF
#!/bin/bash
cd "$INSTALL_DIR"
./n_Queen.bin
EOF
sudo chmod +x "$WRAPPER"

# Create .desktop entry
echo "🖥️  Registering desktop shortcut..."
sudo tee "$DESKTOP_FILE" > /dev/null <<EOF
[Desktop Entry]
Name=N-Queens Game
Comment=Play the classic N-Queens puzzle
Exec=$APP_NAME
Icon=$APP_NAME
Terminal=false
Type=Application
Categories=Game;LogicGame;
StartupNotify=true
EOF

sudo chmod +x "$DESKTOP_FILE"

echo "✅ Installation complete! Launch from app menu or run 'nqueens'"
