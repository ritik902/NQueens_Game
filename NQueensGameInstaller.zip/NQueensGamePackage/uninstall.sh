#!/bin/bash

APP_NAME="nqueens"
INSTALL_DIR="/opt/$APP_NAME"
WRAPPER="/usr/local/bin/$APP_NAME"
ICON_PATH="/usr/share/pixmaps/${APP_NAME}.png"
DESKTOP_FILE="/usr/share/applications/${APP_NAME}.desktop"

read -p "Are you sure you want to uninstall N-Queens Game? (y/N): " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "❌ Uninstall cancelled."
    exit 0
fi

sudo rm -rf "$INSTALL_DIR"
sudo rm -f "$WRAPPER" "$ICON_PATH" "$DESKTOP_FILE"

echo "🧼 N-Queens Game fully removed."
