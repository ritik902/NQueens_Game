$shortcutName = "NQueens Game"
$desktopPath = [Environment]::GetFolderPath("Desktop")
$startMenuPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"

Remove-Item "$desktopPath\$shortcutName.lnk" -ErrorAction SilentlyContinue
Remove-Item "$startMenuPath\$shortcutName.lnk" -ErrorAction SilentlyContinue

Write-Host "🗑️ NQueens Game shortcuts removed from Desktop and Start Menu."
