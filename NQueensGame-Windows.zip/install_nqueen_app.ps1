# Define paths
$exePath = "$PSScriptRoot\n_Queen.dist\n_Queen.exe"
$iconPath = "$PSScriptRoot\icon.ico"
$shortcutName = "NQueens Game"
$desktopPath = [Environment]::GetFolderPath("Desktop")
$startMenuPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"

# Create desktop shortcut
$desktopShortcut = "$desktopPath\$shortcutName.lnk"
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($desktopShortcut)
$sc.TargetPath = $exePath
$sc.IconLocation = $iconPath
$sc.Save()

# Create Start Menu shortcut
$menuShortcut = "$startMenuPath\$shortcutName.lnk"
$sc = $ws.CreateShortcut($menuShortcut)
$sc.TargetPath = $exePath
$sc.IconLocation = $iconPath
$sc.Save()

Write-Host "✅ App shortcut created on Desktop and Start Menu."
